package base;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.RegexFileFilter;

public class Injector {
	public String GetAllfiles(File filepath,File Mainfilepath) {
		File folder = filepath ;
		String CheckJavaFile = "";
		Collection allfiles = FileUtils.listFiles(filepath, new RegexFileFilter(".*\\.java$"),DirectoryFileFilter.DIRECTORY);
		
		//Check if any java files is present in the given Source Package //
		if(allfiles.size()==0)
		{
			return "No Java File found";
		}
		
		else
		{
			//Rule 1 - User will give argument for Entry Class i.e. public static void main if that is not found break//
			String MainFilePath = "";
			String Flag = "";
			String OS = System.getProperty("os.name");
			if(OS.contains("Windows"))
				MainFilePath = filepath.getAbsolutePath().trim() +"\\"+ Mainfilepath;
			else
				MainFilePath = filepath.getAbsolutePath().trim() +"/"+ Mainfilepath;
			
			Flag = ReadBigFile(MainFilePath, "public static void main(String args[])");
			//Case - If Main class is correct having - public static void main(String args[])//
				if(Flag.contentEquals("Found"))
				{
					/**
					 * Injecting print statement in every java class 
					 * This will be helpful in getting executed line number 
					 */
					for(Object f:allfiles)
					{	
						Read_CreateBigFile(f.toString().trim());
					}
				}
				else
					return "Main file is invalid";
		}
		
		
		
		
		
		
		
		return allfiles.toString();	
	
	}
	
	
	/**
     * This function is for reading file lines>10000
     * @param FILENAME
     * @return - Found if SearchString is found else return "NOTFOUND" 
     */
    public String ReadBigFile(String FILENAME,String SearchString)
    {
        String Flag = "NotFound";
       
        try {
             LineIterator it = FileUtils.lineIterator(new File(FILENAME), "UTF-8");
            while (it.hasNext()) {
                String line = it.nextLine();
                if(line.contains("public static void main(String args[])")||line.contains("public static void main(String[] args)"))
                {
                	Flag = "Found";
                	break;
                }                
            }
            
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            //LineIterator.closeQuietly(it);
        }
        return Flag;
    }
    
    /**
     * 
     * @param FILENAME - Read File
     * - Inject print statement - ("ShivamCoverage") after every statement leaving all these values - "{,},space,null line,import lines"    
     * @return void
     */
    public void Read_CreateBigFile(String FILENAME)
    {
        File logfile = new File(FILENAME);
        String logfilename = logfile.getName();
    	ArrayList<String> IT = new ArrayList<String>();
        int linenumber= 1;
        // Reading the File //
        try {
             LineIterator it = FileUtils.lineIterator(new File(FILENAME), "UTF-8");
            while (it.hasNext()) {
                String line = it.nextLine();
                IT.add(line);
            }
            
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            //LineIterator.closeQuietly(it);
        }
        
        String NewFileContents = "";
        // Updating the File //
        for(int i =0 ;i <IT.size() ;i++) {
        	
        	String contents = IT.get(i).trim();
        	if(contents.contains("import ")||contents.contains("package ")||contents.equalsIgnoreCase("{")||contents.equalsIgnoreCase("}")||contents.length()==0||contents.contains("return ")||contents.contains("class")) {
        		int j=i+1;
        		try {
	        		if(IT.get(j).trim().contains("return "))
	    			{
	    				String NextLineContent = IT.get(j).trim();
	    				NewFileContents = NewFileContents+contents+"\n"+"\n System.out.println(\""+logfilename+" = Next Return Line = "+(linenumber+1)+"\");\n";
	    				
	    			}
	        		else
	            		NewFileContents = NewFileContents+contents+"\n";
	        			
	        	}catch(Exception e)
        		{
	        		NewFileContents = NewFileContents+contents+"\n";
	        		
        		}       		        		
        	}
        	else
        	{
        		int j=i+1;
        		try {
        			if(contents.contains("public")||contents.contains("private")||contents.contains("protected")||contents.contains("final")||contents.contains("static"))
        			{
        				char last = contents.charAt(contents.length()-1);
        				System.out.println("Last Character ="+last);
        				//It means its is method//
        				if(last=='{' || IT.get(j).trim().contains("{")||last==';')
        				{
        					NewFileContents = NewFileContents+contents+"\n";
        				}
        				
        			}
        			else
    				{
    					String temp = contents.trim();
    	        		contents = contents.replace(temp, temp+"\n"+"\n System.out.println(\""+logfilename+" = Current Line = "+linenumber+"\");\n");
    	        		NewFileContents = NewFileContents+contents+"\n";
    	        	}
        		}catch(Exception e)
        		{
        			
        		}        		
        	}
        	linenumber++;
        }

   	 try {
   		 String FileNewName = FILENAME.split(".java")[0]+"_NEW.java";
            BufferedWriter out = new BufferedWriter(new FileWriter(FileNewName));
            out.write(NewFileContents);
            out.close();
            System.out.println("New Java File Created");
        }
        catch(IOException e)
        {
            System.out.println("Error in creating Stress Suite");
            e.printStackTrace();
        }
   	 
   	System.out.println("CodeInjected - New Package created");
    }
    
}