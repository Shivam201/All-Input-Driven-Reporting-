package base;

import java.io.File;

public class Driver {
	
	
	/**
	 * Step 1 - Structure of a Java files
	 * Step 2 - inject a print class and line number counter - every line inside a method
	 * Step 3 - create a log [Write class and line number in a file]
	 * Step 4 - Generate a html file on log
	 * @param args
	 */
	public static void main(String[] args) {
		Injector obj = new Injector();
		String directorylocation = "C:\\Users\\MaralayS\\eclipse-workspace\\TestNgJob\\Calculator\\Calculator\\src\\test";
		String MainClasslocation = "Runner.java";
		String x = obj.GetAllfiles(new File(directorylocation),new File(MainClasslocation));
		//System.out.println("x = "+x);
	}

}
