package main;


import java.awt.Paint;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Popup;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Background;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.PopupWindow;
import javafx.stage.Stage;

public class Driver extends Application {

	@SuppressWarnings("rawtypes")
	private TableView table;
	
//    private Text actionStatus;
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 launch(args);
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
    public void start(Stage primaryStage) throws IOException {
        primaryStage.setTitle("ResumeSelector");
        GenericFunction obj = new GenericFunction();
        
        BorderPane border = new BorderPane();
            
/**
 * Initializing GRID -- 
 */ 		
        //*******************************************************************************************************************************************//    
		
        					GridPane grid = new GridPane();
					        grid.setAlignment(Pos.TOP_LEFT);
					        grid.setHgap(10);
					        grid.setVgap(10);
					        grid.setPadding(new Insets(25, 25, 25, 25));
					        
					        Tooltip tp = new Tooltip("Configuration Settings");
					        Label Settings = new Label("Apply Settings"); 
					        Settings.setFont(Font.font("Calibri", FontWeight.BOLD, 20));
					        Settings.setTextFill(Color.CHARTREUSE);
					        grid.add(Settings, 0, 0);
					        
					        // -- LABEL USERNAME-- //
					        Label Folder = new Label("Select Folder contains resume(*)");
					        Folder.setTextFill(Color.PINK);
					        grid.add(Folder, 0, 1);
					
					        TextField ResumeLocationTextField = new TextField();
					        grid.add(ResumeLocationTextField, 1, 1);
					        ResumeLocationTextField.setTooltip(new Tooltip("Folder should contain(allowed format .doc,.docx.pdf)"));
					        
					        
					        final Button openButton = new Button("Open");
					        tp = new Tooltip("Only PDF or DOC/DOCX file are allowed");
					        openButton.setTooltip(tp);	
					        openButton.setMinWidth(10);
					        openButton.setMinHeight(10);
					        grid.add(openButton,2,1);
					        
					        // -- LABEL PASSWORD-- //
					        Label passWord = new Label("Keyword to search (,) seperated (*)");
					        //passWord.setFont(Font.font("Tahoma", FontWeight.NORMAL, 15));
					        passWord.setTextFill(Color.PINK);
					        grid.add(passWord, 0, 2);					
					        TextArea KeywordField  = new TextArea();
					        KeywordField.setPrefHeight(25);
					        KeywordField.setPrefWidth(25);
					        KeywordField.setText("Java , Selenium , Testing , Automation");
					        KeywordField.setWrapText(true);
					        grid.add(KeywordField, 1, 2);
		
					        // Other Keywords Find //
					        Label OtherKeywords = new Label("Other Keywords"); 
					        grid.add(OtherKeywords,2 , 2);
					        OtherKeywords.setTextFill(Color.PINK);
					        TextField OtherKeywordsList  = new TextField();
					        OtherKeywordsList.setText("onsite,istqb,dance,Singing,tabletennis,badminton,event,donation,camp,swim");
					        grid.add(OtherKeywordsList, 3, 2);
					     
						    // Resume Count //   
					        Label CountLabel = new Label("Total Resume to be selected (*)"); 
					        grid.add(CountLabel,0 , 3);
					        CountLabel.setTextFill(Color.PINK);
					       
					        String Counter[] = { "1", "2", "3","4", "5","6","7","8","9","10" };
					        ComboBox<String> TotalResumeNeeded = new ComboBox<String>(FXCollections.observableArrayList(Counter)); 
					        grid.add(TotalResumeNeeded, 1, 3);
		
					     // Companies //   
					        Label Companies = new Label("Companies Whitelisted"); 
					        grid.add(Companies,0 , 4);
					        Companies.setTextFill(Color.PINK);
					        TextArea CompaniesList  = new TextArea();
					        CompaniesList.setPrefHeight(50);
					        CompaniesList.setPrefWidth(25);
					        tp = new Tooltip("Candidate Resume will be checked against these companies");
					        CompaniesList.setTooltip(tp);
					        CompaniesList.setText("Accenture ,Airtel ,Alcatellucent,Allies Interactive Services Pvt. Ltd. ,Amdocs ,AmericanExpress ,Aricent ,Birlasoft ,BankOfAmerica ,Capgemini ,Cisco ,Citibank ,Cognizant ,CreditSuisse,Deloitte ,FaceBook ,Goibibo ,Goldmansac ,Google ,HDFC ,HP ,HSBC ,IBM ,iGate ,Infosys ,JIO ,KPMG ,Microsoft ,MorganStanley ,Myphasis ,Naggaro ,NiiT ,Persistent ,PitneyBowes ,RBS ,Reliance ,Sapient ,Scrum Start ,S&PCapitalIQ ,StandardChartard ,TechMahindra ,TCL ,TCS ,Vodafone ,Wipro ,Wolters Kluwers ,Xoriant Solutions ,Yahoo ,Zensar");
					        //CompaniesList.setWrapText(true);
					        grid.add(CompaniesList, 1, 4);
					       
					        Label CompaniesBL = new Label("Companies Blacklist");
					        tp = new Tooltip("Only in Full Version");
					        CompaniesBL.setTooltip(tp);
					        grid.add(CompaniesBL,2 , 4);
					        CompaniesBL.setTextFill(Color.PINK);
					        TextArea CompaniesBLList  = new TextArea();
					        CompaniesBLList.setPrefHeight(50);
					        CompaniesBLList.setPrefWidth(25);
					        tp = new Tooltip("Only in Full Version");
					        CompaniesBLList.setDisable(true);
					        CompaniesBLList.setText("Only in Full Version - Avoid Candidate from these companies");
					        CompaniesBLList.setWrapText(true);
					        grid.add(CompaniesBLList, 3, 4);
					        
					        
					        // -- Rule checkBox -- //
					        tp = new Tooltip("Rule for the project worked and the total experience");
					        Label RulesLabel = new Label("Apply Rules(atleast 1)"); 
					        RulesLabel.setFont(Font.font("Calibri", FontWeight.BOLD, 20));
					        RulesLabel.setTextFill(Color.CHARTREUSE);
					        grid.add(RulesLabel, 0, 6);
					        
					        final CheckBox Rule1 = new CheckBox("Total Project worked vs Experience");
					        Rule1.setTooltip(tp);
					        Rule1.setTextFill(Color.PINK);
					        Rule1.setSelected(true);
					        grid.add(Rule1, 0, 7);
					        
					        tp = new Tooltip("Rule for the Keywords present in the Resume and how much time");
					        final CheckBox Rule2 = new CheckBox("Keywords % in Resume");
					        Rule2.setTooltip(tp);
					        Rule2.setSelected(true);
					        Rule2.setTextFill(Color.PINK);
					        grid.add(Rule2, 1, 7);  
					        
					        tp = new Tooltip("Other Keywords include - dance events i.e. extra ciricular activities");                
					        final CheckBox Rule3 = new CheckBox("Other Keywords");
					        //Rule3.setTooltip(tp);
					        //Rule3.setDisable(true);
					        Rule3.setSelected(true);
					        Rule3.setTextFill(Color.PINK);
					        grid.add(Rule3, 2, 7);
					        
					        tp = new Tooltip("Check Resume is reliable or not");
					        final CheckBox Rule4 = new CheckBox("Reliability Check");
					        //Rule4.setTooltip(tp);
					        Rule4.setSelected(true);
					        Rule4.setTextFill(Color.PINK);
					        grid.add(Rule4, 3, 7);
					        
					        tp = new Tooltip("General Check about resume should have kind of stuff");
					        final CheckBox Rule5 = new CheckBox("General Check");
					        Rule5.setTooltip(tp);
					        Rule5.setSelected(true);
					        Rule5.setTextFill(Color.PINK);
					        grid.add(Rule5, 0, 8);
					        
					        tp = new Tooltip("Only In Full Version - Black Listed Candidate Filter");
					        final CheckBox Rule6 = new CheckBox("BlackListed Company");
					        Rule6.setTooltip(tp);
					        Rule6.setDisable(true);  
					        Rule6.setSelected(true);
					        Rule6.setTextFill(Color.PINK);
					        grid.add(Rule6, 1, 8);
					       
					        tp = new Tooltip("Only In Full Version - Create Custom Rules");
					        final CheckBox Rule7 = new CheckBox("Custom Rules1");
					        Rule7.setTooltip(tp);
					        Rule7.setDisable(true);  
					        Rule7.setSelected(true);
					        Rule7.setTextFill(Color.PINK);
					        grid.add(Rule7, 2, 8);
					       
					        tp = new Tooltip("Only In Full Version - Create Custom Rules");
					        final CheckBox Rule8 = new CheckBox("Custom Rules2");
					        Rule8.setTooltip(tp);
					        Rule8.setDisable(true);  
					        Rule8.setSelected(true);
					        Rule8.setTextFill(Color.PINK);
					        grid.add(Rule8, 3, 8);				        
					        
					     // -- SignIn Button -- //
					        Button FindResumebtn = new Button("FindResume");
					        FindResumebtn.setFont(Font.font("Calibri", FontWeight.BOLD, 18));
					        //FindResumebtn.setStyle("-fx-background-color: Green");
					        //FindResumebtn.setText);
					        HBox hbBtn = new HBox(10);
					        hbBtn.setAlignment(Pos.BOTTOM_LEFT);
					        hbBtn.getChildren().add(FindResumebtn);
					        grid.add(hbBtn, 1,10);
					        
					        // -- About Button -- //
					        Button About = new Button("About");
					        grid.add(About, 20, 0);
					        
					        
					     // Results //
					        Label label = new Label("Results");
					        label.setTextFill(Color.BROWN);
					        label.setFont(Font.font("Calibri", FontWeight.BOLD, 15));
					        HBox labelHb = new HBox();
					        labelHb.setAlignment(Pos.CENTER);
					        labelHb.getChildren().add(label);

					      //Show Result Table //   
					        table = new TableView();
	//*********************************************************************************************************************************//				       
/**
 * Grid UI        
 */
        
          
      
        //String [] name = {"Shivam Maralay","shivam201@gmail.com","10","Java,Testing,cucumber,jmeter,LnP","YES","onsite,headless","70%"};
        
        // folder location - resume folder location
        // Total Resume needed - 1,2,3,...
        // Keywords +10 if all found else 10/totakeyword = found*(10/totalkeyword)//
        
        
    
 /**
  * All Button Action Listener    
  */
	      //*********************************************************************************************************************************//   

		// Handle FindResume Button //
		        FindResumebtn.setOnAction(new EventHandler() {
					@Override
					public void handle(Event arg0) {				
						// Check 1 - Validate Keywords are present or not //
						boolean ValidateKeyword = false;
						if(KeywordField.getText().length()>=5 && KeywordField.getText().split(",").length>=2 && ResumeLocationTextField.getText().length()>5)
						{
							ValidateKeyword = true;
						}
						else
						{
							Alert a = new Alert(AlertType.NONE); 
		                	// set alert type 
		                    a.setAlertType(AlertType.ERROR); 
		                    a.setTitle("Keyword or Resume Folder Path Missing Error");
		                    a.setContentText("Please check May be Keywords or Folder Path is missing,Atleast 2 Keywords is required");
		                    a.showAndWait(); 
						}
						
						
						// Check 2 - Some Rules should be selected //
						boolean ValidateRules = false;
						if(Rule1.isSelected()||Rule2.isSelected()||Rule3.isSelected()||Rule4.isSelected()
								||Rule5.isSelected()) // ||Rule6.isSelected()) - Since Rule6,7,8 is blank so removing that//
						{
							ValidateRules = true;
						}
						else
						{
							Alert a = new Alert(AlertType.NONE); 
		                	// set alert type 
		                    a.setAlertType(AlertType.ERROR); 
		                    a.setTitle("Atleast 1 rule should be selected");
		                    a.setContentText("Please select atleast 1 rule");
		                    a.showAndWait();
						}
						
						// check 3 - Resume Counter should have some value //
						boolean ValidateResumeCounter = false;
						//System.out.println("value - "+TotalResumeNeeded.getValue());
						if(TotalResumeNeeded.getValue()==null)
						{
							Alert a = new Alert(AlertType.INFORMATION); 
		                	// set alert type 
		                    a.setAlertType(AlertType.INFORMATION); 
		                    a.setTitle("Please select Some value in Total Resume");
		                    a.setContentText("Select some number in Total Resume and try again");
		                    a.showAndWait();
						}
						else
							ValidateResumeCounter = true;
						
						if(ValidateKeyword&&ValidateResumeCounter&&ValidateRules)
						{
							ArrayList Data = new ArrayList<String[]>();
							ArrayList TemporaryList  = new ArrayList<String[]>();
							try {
								TemporaryList = obj.ReadAllFiles(ResumeLocationTextField.getText(),TotalResumeNeeded.getValue(),KeywordField.getText(),CompaniesList.getText(),OtherKeywordsList.getText(),Rule1,Rule2,Rule3,Rule4,Rule5,Rule6);
								if(TemporaryList.size()<Integer.parseInt(TotalResumeNeeded.getValue()))
								{
									Alert a = new Alert(AlertType.INFORMATION); 
				                	// set alert type 
				                    a.setAlertType(AlertType.INFORMATION); 
				                    a.setTitle("Total Resume are less than you are asking for display");
				                    a.setContentText("Showing total Resumes");
				                    a.showAndWait();
								}
								Data = obj.Sort(TemporaryList,6,Integer.parseInt(TotalResumeNeeded.getValue())); // 6 is the Column as of now it is the percentage Column //
							
							//list.add(new Results("Shivam Maralay","shivam201@gmail.com","10","Java,Testing,cucumber,jmeter,LnP","YES","onsite,headless","70%"));
					        //list.add(new Results("NidhiShree Maralay","nidhishree@gmail.com","10","Java,Testing,cucumber,jmeter,LnP","YES","onsite,headless","70%"));
						        
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
				        
				        
				        //loop for inserting the records in the Data arrayList for count = Total Resume to be selected//
				        //Data.add(0,name);
				        
				        // Data Filling //
				        table = obj.CreateResultTable(table,Data);         
				        border.setBottom(table);
						}
						
						else
						{
							//System.out.println("Some Validation are missing");
						}
						
					}
				});
        
        
     // Handle Open Project Button Action //
        
        openButton.setOnAction(new EventHandler<ActionEvent>(){        
        	@Override
			public void handle(ActionEvent arg0) {
        		String value = obj.HandleOpenFolderButton(openButton,primaryStage,ResumeLocationTextField);
        		Tooltip tooltip1 = new Tooltip(value);
        		ResumeLocationTextField.setTooltip(tooltip1);
        	}	
        });
        
// Handle About button //        
        About.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				// TODO Auto-generated method stub
				Alert a = new Alert(AlertType.INFORMATION); 
            	// set alert type 
                a.setAlertType(AlertType.INFORMATION); 
                a.setTitle("About ResumeSelector");
                a.setHeaderText("ResumeSelector - Tool Information");
                a.setContentText("Aim - Smartly selecting Profile from a no: of Resumes \nDeveloped By - Shivam Maralay \nFor Support/Suggestion or Full version\nContact: \n Mail - shivam201@gmail.com\n Mobile - 9871820627");
                a.showAndWait();             	
			}
		});
     
// Handle Setting Button ///
        
        
   /**
    * All Button Action Listener     
    */
        
        
        border.setTop(grid);   
        
        grid.setBackground(Background.EMPTY);
        border.setBackground(Background.EMPTY);
        String style = "-fx-background-color: #2f4f4f;";
        grid.setStyle(style);
        border.setStyle(style);
        primaryStage.setScene(new Scene(border, 900, 640));
        primaryStage.setResizable(false);
        
        primaryStage.show();
    }
}
