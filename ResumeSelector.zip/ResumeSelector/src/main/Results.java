package main;

import javafx.beans.property.SimpleStringProperty;

public class Results{
    private final SimpleStringProperty firstName;
    private final SimpleStringProperty email;
    private final SimpleStringProperty experience;
    private final SimpleStringProperty keywords;
    private final SimpleStringProperty reliable;
    private final SimpleStringProperty others;
    private final SimpleStringProperty strength;
    
    Results(String fName, String email,String Experience,String Keywords,String Reliable,String Others,String Strength) {
        this.firstName = new SimpleStringProperty(fName);
        this.email = new SimpleStringProperty(email);
        this.experience = new SimpleStringProperty(Experience);
        this.keywords = new SimpleStringProperty(Keywords);
        this.reliable = new SimpleStringProperty(Reliable);
        this.others = new SimpleStringProperty(Others);
        this.strength = new SimpleStringProperty(Strength);
    }
 
    public String getFirstName() {
        return firstName.get();
    }
    public void setFirstName(String fName) {
        firstName.set(fName);
    }
    
    public String getEmail() {
        return email.get();
    }
    public void setEmail(String fName) {
        email.set(fName);
    }
    
    public String getExperience() {
        return experience.get();
    }
    public void setNumber(String fName) {
        experience.set(fName);
    }
    
    public String getKeywords() {
        return keywords.get();
    }
    public void setKeywords(String fName) {
        keywords.set(fName);
    }

    public String getReliable() {
        return reliable.get();
    }
    public void setReliable(String fName) {
        reliable.set(fName);
    }   
    
    public String getOthers() {
        return others.get();
    }
    public void setOthers(String fName) {
        others.set(fName);
    }
    
    public String getStrength() {
        return strength.get();
    }
    public void setStrength(String fName) {
        strength.set(fName);
    }
    
}