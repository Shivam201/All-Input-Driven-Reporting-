package main;
import java.util.Optional;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;
import javafx.util.Pair;

public class SettingPage extends Application {
	public static void main(String args[])
	{
		launch(args);
	}
	public void start(Stage s) throws Exception {
		Dialog<Pair<String,String>> dialog = new Dialog<>();
		dialog.setTitle("New Input dialog");
		
		ButtonType loginbuttontype = new ButtonType("OK",ButtonData.OK_DONE);
		dialog.getDialogPane().getButtonTypes().addAll(loginbuttontype,ButtonType.CANCEL);
		
		GridPane gridPane = new GridPane();
		gridPane.setHgap(10);
		gridPane.setHgap(10);
		
		TextField from = new TextField();
		from.setPromptText("From");
		
		TextField to = new TextField();
		to.setPromptText("To");
		
		gridPane.add(from, 0,0);
		gridPane.add(new Label("To:"),1,0);
		gridPane.add(to,2,0);
		dialog.getDialogPane().setContent(gridPane);
		
		System.out.println("");
		
		Platform.runLater(()->from.requestFocus());
		
		dialog.setResultConverter(dialogButton -> {
			if(dialogButton == loginbuttontype) {
				return new Pair<>(from.getText() ,to.getText());
			}
			return null;
		});
		
		Optional<Pair<String,String>> result = dialog.showAndWait();
		result.ifPresent(pair-> {
			System.out.println("From = "+pair.getKey()+", to = "+pair.getValue());
		});
 		
	}
}
