package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import com.sun.javafx.applet.ExperimentalExtensions;

import javafx.animation.Animation.Status;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Control;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.text.Text;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.util.Callback;

public class GenericFunction {
	private ObservableList<Results> Resultdata;
	// Handling the Button Action//
	/**
	 * Handle Open Project Button
	 * @return 
	 */
	public String HandleOpenFolderButton(Button openButton,Stage primaryStage,TextField FolderPath) {
		// TODO Auto-generated method stub
		final DirectoryChooser directoryChooser = new DirectoryChooser();
        configuringDirectoryChooser(directoryChooser);
		File dir = directoryChooser.showDialog(primaryStage);
        if (dir != null) {
                	File folder = new File(dir.getAbsolutePath());
                	File[] listOfFiles = folder.listFiles();
                	
                	String AllFiles = "";
                	for (File file : listOfFiles) {
                	    AllFiles = AllFiles+file.getName();
                	}

    	    		if (AllFiles.contains(".pdf")||AllFiles.contains(".PDF")||AllFiles.contains(".Pdf")&&AllFiles.contains(".doc")||AllFiles.contains(".DOC")||AllFiles.contains(".Doc")||AllFiles.contains(".docx")||AllFiles.contains(".DOCX")||AllFiles.contains(".Docx")) {
    	    			FolderPath.setText(dir.getAbsolutePath());
    	    			return dir.getAbsolutePath();
            	    }
    	    		else
    	    		{
    	    			Alert a = new Alert(AlertType.NONE); 
                    	// set alert type 
                        a.setAlertType(AlertType.ERROR); 
                        a.setTitle("Folder not containing any .pdf or .doc or .docx files");
                        // show the dialog 
                        a.showAndWait(); 
                        return "No Valid File Found";
    	    		}
                    
                } else {
                	FolderPath.setText("Please select Some directory");
                	return "No Folder Selected";
                }
			}
		        	
	public String ValidationCheck(Button openButton,Stage primaryStage,TextField FolderPath) {
		// TODO Auto-generated method stub
		final DirectoryChooser directoryChooser = new DirectoryChooser();
        configuringDirectoryChooser(directoryChooser);
		File dir = directoryChooser.showDialog(primaryStage);
        if (dir != null) {
                	
                	File folder = new File(dir.getAbsolutePath());
                	File[] listOfFiles = folder.listFiles();
                	
                	String AllFiles = "";
                	for (File file : listOfFiles) {
                	    AllFiles = AllFiles+file.getName();
                	}

    	    		if (AllFiles.contains(".pdf")||AllFiles.contains(".PDF")||AllFiles.contains(".Pdf")&&AllFiles.contains(".doc")||AllFiles.contains(".DOC")&&AllFiles.contains(".Doc")) {
    	    			FolderPath.setText(dir.getAbsolutePath());
    	    			return dir.getAbsolutePath();
            	    }
    	    		else
    	    		{
    	    			Alert a = new Alert(AlertType.NONE); 
                    	// set alert type 
                        a.setAlertType(AlertType.ERROR); 
                        a.setTitle("Folder not containing any .pdf or .doc or .docx files");
                        // show the dialog 
                        a.showAndWait(); 
                        return "No Valid File Found";
    	    		}
                    
                } else {
                	FolderPath.setText("Please select Some directory");
                	return "No Folder Selected";
                }
			}    
	
	
	private void configuringDirectoryChooser(DirectoryChooser directoryChooser) {
        // Set title for DirectoryChooser
        directoryChooser.setTitle("Select Some Directories");
 
        // Set Initial Directory
        directoryChooser.setInitialDirectory(new File(System.getProperty("user.home")));
    }
	
	
	public String ReadPDF(File PDFFile) throws IOException
	{
		String Content = "";
		try (PDDocument document = PDDocument.load(PDFFile)) {

            document.getClass();

            if (!document.isEncrypted()) {
			
                PDFTextStripperByArea stripper = new PDFTextStripperByArea();
                stripper.setSortByPosition(true);

                PDFTextStripper tStripper = new PDFTextStripper();

                String pdfFileInText = tStripper.getText(document);
                //System.out.println("Text:" + st);

				// split by whitespace
                String lines[] = pdfFileInText.split("\\r?\\n");
                for (String line : lines) {
                	Content = Content + line;
                }
            }
        }
		return Content;
	}
	
	public String ReadWORD(File WORDFile)
	{
		String Content = "";
		String Filename = WORDFile.getName();
		if(WORDFile.getName().contains(".docx")) 
		{
			try {
				File file = WORDFile;
				FileInputStream fis = new FileInputStream(file.getAbsolutePath());

				XWPFDocument document = new XWPFDocument(fis);

				List<XWPFParagraph> paragraphs = document.getParagraphs();
				
				//System.out.println("Total no of paragraph "+paragraphs.size());
				for (XWPFParagraph para : paragraphs) {
					//System.out.println(para.getText());
					Content = Content+para.getText();
				}
				fis.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		else {
			try {
				File file = WORDFile;
				FileInputStream fis = new FileInputStream(file.getAbsolutePath());

				HWPFDocument doc = new HWPFDocument(fis);

				WordExtractor we = new WordExtractor(doc);

				String[] paragraphs = we.getParagraphText();
				
				//System.out.println("Total no of paragraph "+paragraphs.length);
				for (String para : paragraphs) {
					//System.out.println(para.toString());
					Content = Content+para.toString();
				}
				fis.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return Content;
	}
	
	@SuppressWarnings("rawtypes")
	ObservableList getInitialTableData(ArrayList<String[]> Data) {
        
        @SuppressWarnings("unchecked")
		List<Results> list = new ArrayList();
        //list.add(new Results("Shivam Maralay","shivam201@gmail.com","10","Java,Testing,cucumber,jmeter,LnP","YES","onsite,headless","70%"));
        //list.add(new Results("NidhiShree Maralay","nidhishree@gmail.com","10","Java,Testing,cucumber,jmeter,LnP","YES","onsite,headless","70%"));
        
        for(int i=0;i<Data.size();i++)
        {
        	String temp[] = Data.get(i);
        	String name = temp[0].trim();
        	String emailid= temp[1].trim();
        	String experience = temp[2].trim();
        	String keyword = temp[3].trim();
        	String reliable = temp[4].trim();
        	String others = temp[5].trim();
        	String percentage = temp[6].trim();
        	
        	list.add(new Results(name,emailid,experience,keyword,reliable,others,percentage));
        }
        
        
        ObservableList data = FXCollections.observableList(list);
        return data;
    }

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public TableView CreateResultTable(TableView table,ArrayList<String[]> Data) {
		
        Resultdata = getInitialTableData(Data);
        table.setItems(Resultdata);
        
        TableColumn Name = new TableColumn("CandidateName");
        Name.setCellValueFactory(new PropertyValueFactory("firstName"));
        Name.setCellFactory(TextFieldTableCell.forTableColumn());
        
        Name.setCellFactory(new Callback<TableColumn<Status, String>, TableCell<String, String>>() {
			@Override
			public TableCell<String, String> call(TableColumn<Status, String> arg0) {
				TableCell<String, String> cell = new TableCell<>();
	            Text text = new Text();
	            cell.setGraphic(text);
	            cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
	            text.wrappingWidthProperty().bind(cell.widthProperty());
	            text.textProperty().bind(cell.itemProperty());
	            return cell ;
			}

        });
        
        
        
        TableColumn emailid = new TableColumn("CandidateEmailID");
        emailid.setCellValueFactory(new PropertyValueFactory("email"));
        emailid.setCellFactory(TextFieldTableCell.forTableColumn());

        emailid.setCellFactory(new Callback<TableColumn<Status, String>, TableCell<String, String>>() {
			@Override
			public TableCell<String, String> call(TableColumn<Status, String> arg0) {
				TableCell<String, String> cell = new TableCell<>();
	            Text text = new Text();
	            cell.setGraphic(text);
	            cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
	            text.wrappingWidthProperty().bind(cell.widthProperty());
	            text.textProperty().bind(cell.itemProperty());
	            return cell ;
			}

        });
        
        TableColumn experience = new TableColumn("Experience(in Years)");
        experience.setCellValueFactory(new PropertyValueFactory("experience"));
        experience.setCellFactory(TextFieldTableCell.forTableColumn());
        experience.setCellFactory(new Callback<TableColumn<Status, String>, TableCell<String, String>>() {
			@Override
			public TableCell<String, String> call(TableColumn<Status, String> arg0) {
				TableCell<String, String> cell = new TableCell<>();
	            Text text = new Text();
	            cell.setGraphic(text);
	            cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
	            text.wrappingWidthProperty().bind(cell.widthProperty());
	            text.textProperty().bind(cell.itemProperty());
	            return cell ;
			}

        });
        
        
        TableColumn keywords = new TableColumn("Keywords found %");
        keywords.setCellValueFactory(new PropertyValueFactory("Keywords"));
        keywords.setCellFactory(TextFieldTableCell.forTableColumn());
        keywords.setCellFactory(new Callback<TableColumn<Status, String>, TableCell<String, String>>() {
			@Override
			public TableCell<String, String> call(TableColumn<Status, String> arg0) {
				TableCell<String, String> cell = new TableCell<>();
	            Text text = new Text();
	            cell.setGraphic(text);
	            cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
	            text.wrappingWidthProperty().bind(cell.widthProperty());
	            text.textProperty().bind(cell.itemProperty());
	            return cell ;
			}

        });
        
        TableColumn reliable = new TableColumn("Reliable");
        reliable.setCellValueFactory(new PropertyValueFactory("reliable"));
        reliable.setCellFactory(TextFieldTableCell.forTableColumn());
        reliable.setCellFactory(new Callback<TableColumn<Status, String>, TableCell<String, String>>() {
			@Override
			public TableCell<String, String> call(TableColumn<Status, String> arg0) {
				TableCell<String, String> cell = new TableCell<>();
	            Text text = new Text();
	            cell.setGraphic(text);
	            cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
	            text.wrappingWidthProperty().bind(cell.widthProperty());
	            text.textProperty().bind(cell.itemProperty());
	            return cell ;
			}

        });

        TableColumn Others = new TableColumn("Others");
        Others.setCellValueFactory(new PropertyValueFactory("others"));
        Others.setCellFactory(TextFieldTableCell.forTableColumn());
        Others.setCellFactory(new Callback<TableColumn<Status, String>, TableCell<String, String>>() {
			@Override
			public TableCell<String, String> call(TableColumn<Status, String> arg0) {
				TableCell<String, String> cell = new TableCell<>();
	            Text text = new Text();
	            cell.setGraphic(text);
	            cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
	            text.wrappingWidthProperty().bind(cell.widthProperty());
	            text.textProperty().bind(cell.itemProperty());
	            return cell ;
			}

        });
        
        TableColumn ResumeStrength = new TableColumn("ResumeStrength");
        ResumeStrength.setCellValueFactory(new PropertyValueFactory("strength"));
        ResumeStrength.setCellFactory(TextFieldTableCell.forTableColumn());
        ResumeStrength.setCellFactory(new Callback<TableColumn<Status, String>, TableCell<String, String>>() {
			@Override
			public TableCell<String, String> call(TableColumn<Status, String> arg0) {
				TableCell<String, String> cell = new TableCell<>();
	            Text text = new Text();
	            cell.setGraphic(text);
	            cell.setPrefHeight(Control.USE_COMPUTED_SIZE);
	            text.wrappingWidthProperty().bind(cell.widthProperty());
	            text.textProperty().bind(cell.itemProperty());
	            return cell ;
			}

        });
        
      
        table.getColumns().setAll(Name,emailid,experience,keywords,reliable,Others,ResumeStrength);
        table.setPrefWidth(400);
        table.setPrefHeight(300);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
 

		return table;
	}
	
	/**
	 * Function
	 * @param Contents
	 * @param Stringpattern
	 * @return - First Match String
	 */
	public String PatternFinderFirstMatch(String Contents,String Stringpattern)
	{
		String firstMatch = "NotFound";
		try {
		Pattern pattern = Pattern.compile(Stringpattern);
		String Content = Contents;
		
		ArrayList<String> list = new ArrayList<String>();
		Matcher m = pattern.matcher(Content);
		while (m.find()) {
		    list.add(m.group());
		    //System.out.println("");
		}
		//System.out.println(list.get(0));		
		firstMatch = list.get(0).trim();
		}
		catch(Exception e)
		{
			
		}
		return firstMatch;
	}

	/**
	 * Count the highest number of Project
	 * @param Contents
	 * @return default 3 project else Count the total project
	 */
	public int ProjectCounter(String Contents)
	{
		String Content = Contents.toLowerCase();
		String AllProject[] = Content.split("project");
		String projectcount = "";
		int Count = 0;
		try {
			for(int i=0;i<AllProject.length;i++)
			{
				int j=i+1;
				String Next = AllProject[j];
				for(int counter =0;counter<15;counter++)
				{
					try { projectcount = projectcount+Next.charAt(counter);}
					catch(Exception e)
					{
						//System.out.println("");
					}
				}
			}
		}catch(Exception e)
		{
			System.out.println("");
		}
		
		//System.out.println("Project = "+projectcount);
		ArrayList<Integer> Projects = new ArrayList<Integer>();
		for(int i=0;i<projectcount.length();i++)
		{
			char val = projectcount.charAt(i);
			if(Character.isDigit(val))
			{
				Projects.add(Integer.parseInt(""+val));
			}
		}
		Collections.sort(Projects);
		
		for(int temp:Projects)
		{
			//System.out.println("temp ="+temp);
			Count = temp;
		}
		if(Count ==0)
		{
			return 3;
		}
		// It means No project is present in Resume , //	
		if(AllProject.length==0)
		Count = 0;
		
		return Count;
	}
	
	public ArrayList<String> ReadAllFiles(String FolderLocation,String Counter,String Keywords,String Company_list , String Others , CheckBox Rule1,CheckBox Rule2,CheckBox Rule3,CheckBox Rule4,CheckBox Rule5,CheckBox Rule6) throws IOException
	{
		ArrayList AllFiles = new ArrayList<String>();
		List<String> AllJMX = new ArrayList<String>();
	    File[] file = new File(FolderLocation).listFiles();
	    int FileCounter = 0;
	    for(File f1 : file)
	    {
	    	String Contents = "";
	    	if(f1.getName().contains(".doc")||f1.getName().contains(".docx")||f1.getName().contains(".Doc")||f1.getName().contains(".Docx"))
	    	{
	    		Contents = ReadWORD(f1);
	    	}

	    	if(f1.isFile() && (f1.getName().contains(".pdf")||f1.getName().contains(".PDF")||f1.getName().contains(".Pdf")))
	    	{
	    		Contents = ReadPDF(f1);
	    	}	
	    	

	    	
	    	AllJMX.add(f1.getName());
	    	//System.out.println("File present = "+f1.getName());
    		
    	    // Data Filling //
    	    String NameFile = f1.getName();
    	    String EmailId = (PatternFinderFirstMatch(Contents, " (.*)@(.*)mail.com | (.*)@yahoo.com| (.*)@yahoo.in|Email: (.*)@yahoo.com"));
	    	EmailId = EmailId.split(" ")[EmailId.split(" ").length-1];
    	    
    	    String Years = PatternFinderFirstMatch(Contents, "\\d+\\.\\d [Y|y]ears|\\d [Y|y]ears");
	    	Years = Years.replaceAll("Years","").replaceAll("years","");
	    	Years = Years.split(" ")[Years.split(" ").length-1];
    	   
	    	
	    	 // Rule 1 - HomManyProjectWorked //
    	    String Reliable;
    	    String Companylist = Company_list;
    	    String ProjectReliable = "";
    	    String CompanyReliable = "";
    	    int YearRoundValue = 0;
    	    
	    	if(!Rule1.isSelected())
    	    {
    	    	CompanyReliable = "No Data Because Rule1 is not enabled";
    	    }
    	    
    	    
	    	
	    	
	    	// Rule 2- Keyword Found - Formula - Found*(10/TotalKeyword) //
    	    int KeywordsScore = 0;
    	    String KeywordFound = "No Data because Rule2 Not Enabled";
    	    if(Rule2.isSelected())
    	    {
    	    	KeywordsScore = CheckKeywordScore(Contents,Keywords);
    	    	KeywordFound = GetKeywordScore(Contents, Keywords);
    	    }	
    	        	    
    	    if(Years.equalsIgnoreCase("NotFound"))
	    	{
    	    	ProjectReliable = "Cannot Check";
    	    	CompanyReliable = "Cannot Check";
	    	}
    	    else 
	    	{
    	    	if(Years.contains(".")) 
    	    		YearRoundValue = Math.round(Float.parseFloat(Years));
    	    	else
    	    		YearRoundValue = Integer.parseInt(Years);
    	    	
    	    	
    	    	ProjectReliable = ProjectCount(Contents,YearRoundValue);
    	    	CompanyReliable = HowManyCompanies(Contents,Companylist,YearRoundValue);
	    	}
    	    
    	   
    	    	Reliable = ReliabilityCheck(CompanyReliable, ProjectReliable);
    	   
    	    
    	    if(!Rule4.isSelected())
    	    {
    	    	Reliable = "No Data Because Rule4 is not enabled_0";
    	    }
    	    
    	    // Rule 3 - Others //
	    	String others = Others;
	    	String otherstrength = CheckOtherStrength(Contents,others);
	    	String otherstrengthstring = CheckOtherStrengthKeywords(Contents,others);
	    	
	    	if(!Rule3.isSelected())
	    	{
	    		otherstrengthstring = "No Data Because Rule3 is not selected";
	    		otherstrength = "";
	    	}
	    	
	    	//Small Checks//
	    	String PhoneNumber = PatternFinderFirstMatch(Contents, "\\d{10}");
	    	PhoneNumber = "Found";
	    	String Date = ContainsIgnoreCase(Contents, "Date");
	    	Date = "Found";	    	
	    	String LanguageFinder = ContainsIgnoreCase(Contents, "Language");
	    	LanguageFinder = "Found";
	    	String Responsibities = ContainsIgnoreCase(Contents, "Responsibilities");
	    	Responsibities = "Found";
	    	String Roles = ContainsIgnoreCase(Contents, "Roles");
	    	Roles = "Found";
	    	
	    	
	    	//Final - Keywords + Reliability + other + SmallGoodtohavequalities[Sign of good resume]//
	    	// Weightage - 30 + 30 + 15 + 25 //
	    	/**
	    	 * If all keyword found = 30/totalKeyword*KeywordsCount
	    	 * Reliability = if both good than 30 , if both not good than 5 , if one of them is good 20 , if OK than 15
	    	 * other = 15 max - qualities * 2.
	    	 * GoodtoHave = max 25 - if all matched else matched *5 
	    	 */
	    	
	    	int Rule1_Keywords = (30/Keywords.split(",").length)*KeywordsScore;
	    	
	    	int Rule2_keywords = 0;
	    	Rule2_keywords = Integer.parseInt(Reliable.split("_")[1].trim());
	    	Reliable = Reliable.split("_")[0].trim();
	    	
	    	
	    	int Rule3_other = 2*(otherstrengthstring.split(",").length)+1;
	    	if(Rule3_other>15)
	    		Rule3_other = 15;
	    	
	    	int Rule4_GoodToHave = 0;
	    	if(PhoneNumber.equalsIgnoreCase("found")) Rule4_GoodToHave+=5;
	    	if(Date.equalsIgnoreCase("found")) Rule4_GoodToHave+=5;
	    	if(LanguageFinder.equalsIgnoreCase("found")) Rule4_GoodToHave+=5;
	    	if(Responsibities.equalsIgnoreCase("found")) Rule4_GoodToHave+=5;
	    	if(Roles.equalsIgnoreCase("found")) Rule4_GoodToHave+=5;
	    	
	    	if(!Rule5.isSelected())
	    	{
	    		Rule4_GoodToHave = 0;
	    	}
	    	String ResumeStrength = ""+(Rule1_Keywords+Rule2_keywords+Rule3_other+Rule4_GoodToHave)+"%";    	
	    	String [] name = {f1.getName(),EmailId,Years,KeywordFound,Reliable,otherstrengthstring,ResumeStrength};
	    	AllFiles.add(FileCounter, name);
	    	FileCounter++;
	    }	      
		return AllFiles;
	}
	
	/**
	 * Return 
	 * @param Contents
	 * @param Keywords
	 * @return
	 */
	public int CheckKeywordScore(String Contents,String Keywords)
	{
		Keywords = Keywords.replaceAll(" ", ",");
		String allkeywords[] = Keywords.split(",");
		int Found_Counter = 0;
		for(int i=0;i<allkeywords.length;i++)
		{
			if(ContainsIgnoreCase(Contents, allkeywords[i].trim()).equalsIgnoreCase("MATCH")&& allkeywords[i].length()>0)
				Found_Counter++;
		}
		
		
		return Found_Counter;
	}
	
	/**
	 * 
	 * @param Contents
	 * @param Keywords
	 * @return
	 */
	public String GetKeywordScore(String Contents,String Keywords)
	{
		Keywords = Keywords.replaceAll(" ", ",");
		String allkeywords[] = Keywords.split(",");
		String Found = "";
		int Score = 0;
		for(int i=0;i<allkeywords.length;i++)
		{
			if(ContainsIgnoreCase(Contents, allkeywords[i].trim()).equalsIgnoreCase("MATCH")&& allkeywords[i].length()>0)
				Found = Found + allkeywords[i].trim()+",";
		}
		
		if(Found.length()>0 && Found.charAt(Found.length()-1)==',')
		{
			Found = Found.substring(0, Found.length()-1);
		}
		
		return Found;
	}
	
	
	/**
	 * 
	 * @param Contents
	 * @param containsstring
	 * @return
	 */
	public String ContainsIgnoreCase(String Contents,String containsstring)
	{
		if(Contents.toLowerCase().contains(containsstring.toLowerCase()))
		return "MATCH";
		else
			return "NOTMATCH";
	}
	
	/**
	 * Total Project Count > 1
	 * @param Contents
	 * @param Experience
	 * @return
	 */
	public String ProjectCount(String Contents,int Experience)
	{
		// No of Projects worked//
		// Default = 3 if nothing found //
		//Experience =8.5 , Project = 6//
		int TotalProjectWorked = ProjectCounter(Contents);
		if(TotalProjectWorked==0)	return "NOTGOOD";
		else if(TotalProjectWorked<((Experience/2)-1))	return "OK";
		else if(TotalProjectWorked>=(Experience*2-1))   return "OK";
		else return "GOOD";
		
	}
	
	/**
	 * More Experience less company means resume is good
	 * @param Contents
	 * @param ListofCompanies
	 * @param Experience
	 * @param Project
	 * @return
	 */
	public String HowManyCompanies(String Contents,String ListofCompanies,int Experience)
	{
		String Content = Contents.toLowerCase();
		int CompanyyouWorked = 0 ;
		String [] Companies = ListofCompanies.split(" ");
		for(int i =0;i<Companies.length;i++)
		{
			if(Contents.contains(Companies[i].toLowerCase()))
			{
				CompanyyouWorked++;
			}
		}
		
		if(ListofCompanies.length()<5) return "OK";
		if(Experience>(CompanyyouWorked/2)) return "GOOD";
		if(Experience<CompanyyouWorked) return "NOTGOOD";
		else
			return "OK";
		// more Rules can be added//
	}
	
	public String ReliabilityCheck(String CompanyReliable,String ProjectReliable)
	{
		String Reliable = "";
		
	    if(CompanyReliable.equalsIgnoreCase("GOOD") && ProjectReliable.equalsIgnoreCase("GOOD"))
	    {
	    	Reliable = "Candidate is reliable and good Experienced_30";
	    }
	    else if(CompanyReliable.equalsIgnoreCase("GOOD") && ProjectReliable.equalsIgnoreCase("NOTGOOD"))
	    {
	    	Reliable = "Candidate is reliable  But Less Experienced_20";
	    }
	    else if(CompanyReliable.equalsIgnoreCase("GOOD") && ProjectReliable.equalsIgnoreCase("OK"))
	    {
	    	Reliable = "Candidate is reliable and Experienced upto the mark_25";
	    }
	    else if(CompanyReliable.equalsIgnoreCase("NOTGOOD")&& ProjectReliable.equalsIgnoreCase("NOTGOOD"))
	    {
	    	Reliable = "Candidate is neither Reliable nor Experienced_5";
	    }
	    else if(CompanyReliable.equalsIgnoreCase("NOTGOOD")&& ProjectReliable.equalsIgnoreCase("GOOD"))
	    {
	    	Reliable = "Candidate is not Reliable But Experienced_15";
	    }
	    else if(CompanyReliable.equalsIgnoreCase("NOTGOOD")&& ProjectReliable.equalsIgnoreCase("OK"))
	    {
	    	Reliable = "Candidate is not Reliable and OK OK Experience_12";
	    }
	    else if(CompanyReliable.equalsIgnoreCase("OK") && ProjectReliable.equalsIgnoreCase("GOOD"))
	    {
	    	Reliable = "Candidate is good Experienced and Switch wise OK_15";
	    }
	    else if(CompanyReliable.equalsIgnoreCase("OK") && ProjectReliable.equalsIgnoreCase("NOTGOOD"))
	    {
	    	Reliable = "Candidate is not well Experienced and Switch wise OK_15";
	    }
	    else if(CompanyReliable.equalsIgnoreCase("OK") && ProjectReliable.equalsIgnoreCase("OK"))
	    {
	    	Reliable ="Experienced and Switch wise candidate is OK_15";
	    }
	    else
	    	Reliable = "Reliability for this resume cannot be checked_1";
	    
	    
	 return Reliable;   
	}
	
	/**
	 * return good in otherstrength or not
	 * @param Contents
	 * @param others
	 * @return
	 */
	public String CheckOtherStrength(String Contents,String others) 
	{
		String Content = Contents.toLowerCase();
		String Result = "";
		int Counter = 0;
		String Other[] = others.split(",");
		for(int i =0;i<Other.length;i++)
		{
			if(Content.contains(Other[i].toLowerCase()))
			{
				Counter++;
			}
		}
		if(Counter>=5) return "GOOD";
		else if(Counter>=2) return "OK";
		else return "NOTGOOD";
			
	}
	
	/**
	 * return all other strength
	 * @param Contents
	 * @param others
	 * @return
	 */
	public String CheckOtherStrengthKeywords(String Contents,String others) 
	{
		String Content = Contents.toLowerCase();
		String Result = "";
		
		String Other[] = others.split(",");
		for(int i =0;i<Other.length;i++)
		{
			if(Content.contains(Other[i].toLowerCase()))
			{
				Result = Result + Other[i].trim()+",";
			}
		}
		
		if(Result.length()>0 && Result.charAt(Result.length()-1)==',')
		{
			Result = Result.substring(0,Result.length()-1);
		}
		return Result;			
	}
	
	
	/**
	 * 
	 * @param OldList
	 * @param ColumnCount - Starting with 0
	 * @return
	 */
	public ArrayList<String[]> Sort(ArrayList<String[]> OldList,int ColumnCount,int ResumeCounterTobeDisplayed) 
	{
		ArrayList<String[]> NewList = new ArrayList<String[]>();
		//list.add(new Results("Shivam Maralay","shivam201@gmail.com","10","Java,Testing,cucumber,jmeter,LnP","YES","onsite,headless","70%"));
        //list.add(new Results("NidhiShree Maralay","nidhishree@gmail.com","10","Java,Testing,cucumber,jmeter,LnP","YES","onsite,headless","70%"));
        /*ArrayList<String> PercentageList = new ArrayList<String>();
        
		/*for(int i=0;i<OldList.size();i++)
        {
        	String percentage = OldList.get(i)[ColumnCount];
        	PercentageList.add(i, percentage.trim());
        }
        //Sorted as per percentage //
		/*Collections.sort(PercentageList);
		
		for(int i=PercentageList.size()-1;i>=0;i--) //10%, 20%,30%....80% - Sorted percentage List //
		{
			String PercentageListValue = PercentageList.get(i);
			
			// for loop another //
			for(int j=0;j<OldList.size();j++)	// Old List 20% 30% 10%...80% //
			{
				
				StringBuilder sb = new StringBuilder();
				for (String ch : OldList.get(j)) { 
		            sb.append(ch); 
		        } 
				String OldListValue = sb.toString(); 
				
				if(OldListValue.contains(PercentageListValue))
				{
					NewList.add(OldList.get(j));
					break;
				}
				
				else
					continue;
			}
		}
		OldList = NewList;
        NewList = new ArrayList<String[]>();
        for(int i=0;i<ResumeCounterTobeDisplayed;i++)
        {
        	NewList.add(OldList.get(i));
        }
        
        
		return NewList;
        */
		try {
			for(int i=0;i<ResumeCounterTobeDisplayed;i++)
	        {
	        	NewList.add(OldList.get(i));
	        }
		}
		catch(Exception e)
		{
			
		}
		return NewList;
	}
	
	
}
